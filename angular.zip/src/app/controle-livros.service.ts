import { Injectable } from '@angular/core';
import { Livro } from './livro';

@Injectable({
  providedIn: 'root',
})
export class ControleLivrosService {
  livros: Livro[] = [
    new Livro(1, 1, 'Livro A', 'Resumo do Livro A', ['Autor A1', 'Autor A2']),
    new Livro(2, 2, 'Livro B', 'Resumo do Livro B', ['Autor B1', 'Autor B2']),
    new Livro(3, 3, 'Livro C', 'Resumo do Livro C', ['Autor C1', 'Autor C2']),
  ];

  constructor() {}

  obterLivros() {
    return this.livros;
  }

  incluir(livro: Livro) {
    const maiorCodigo = Math.max(...this.livros.map((livro) => livro.codigo));

    livro.codigo = maiorCodigo + 1;

    this.livros.push(livro);
  }

  excluir(codigo: number) {
    const indice = this.livros.findIndex((livro) => livro.codigo === codigo);

    if (indice >= 0) {
      this.livros.splice(indice, 1);
    }
  }
}
