import { Injectable } from '@angular/core';
import { Editora } from './editora';

@Injectable({
  providedIn: 'root',
})
export class ControleEditoraService {
  editoras: Editora[] = [
    new Editora(1, 'Editora A'),
    new Editora(2, 'Editora B'),
    new Editora(3, 'Editora C'),
  ];

  constructor() {}

  getEditoras() {
    return this.editoras;
  }

  getNomeEditora(codEditora: number) {
    const [editora] = this.editoras.filter(
      (editora) => editora.codEditora === codEditora
    );

    if (!editora) {
      return '';
    }

    return editora.nome;
  }
}
